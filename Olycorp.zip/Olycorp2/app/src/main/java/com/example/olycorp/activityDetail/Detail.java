package com.example.olycorp.activityDetail;

import android.view.View;

public class Detail {
    public String text;
    public int image;

    Detail(String txt, int img)
    {
        text = txt;
        image = img;
    }
}

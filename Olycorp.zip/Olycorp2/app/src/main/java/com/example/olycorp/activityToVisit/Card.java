package com.example.olycorp.activityToVisit;

public class Card {

    public String nameCard;
    public int imageA;

    public Card(String name, int image) {
        nameCard = name;
        imageA = image;
    }

}

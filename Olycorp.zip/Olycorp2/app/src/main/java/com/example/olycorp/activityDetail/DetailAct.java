package com.example.olycorp.activityDetail;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.olycorp.R;

public class DetailAct extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_act);
    }
}